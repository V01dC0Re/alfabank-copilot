https://github.com/V01dC0Re/alfabank-copilot
